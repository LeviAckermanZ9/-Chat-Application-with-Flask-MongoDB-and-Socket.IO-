
import os
from flask import Flask, render_template, request, redirect, session, url_for
from flask_socketio import SocketIO, join_room, leave_room, send
from dotenv import load_dotenv
from supabase import create_client

load_dotenv()
app = Flask(__name__)
app.config['SECRET_KEY'] = 'supersecret'
socketio = SocketIO(app)

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

@app.route('/')
def home():
    if 'user' in session:
        return redirect(url_for('join'))
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = supabase.auth.sign_in_with_password(email=email, password=password)
        if user:
            session['user'] = user.user.email
            return redirect(url_for('join'))
        return 'Login failed'
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        supabase.auth.sign_up(email=email, password=password)
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

@app.route('/join', methods=['GET', 'POST'])
def join():
    if 'user' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        room = request.form['room']
        return redirect(url_for('chat', room=room))
    return render_template('index.html')

@app.route('/chat/<room>')
def chat(room):
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('chat.html', room=room, username=session['user'])

@socketio.on('message')
def handle_message(data):
    send({'msg': f"{data['username']}: {data['msg']}"}, room=data['room'])

@socketio.on('join')
def on_join(data):
    join_room(data['room'])
    send({'msg': f"{data['username']} has joined the room."}, room=data['room'])

@socketio.on('leave')
def on_leave(data):
    leave_room(data['room'])
    send({'msg': f"{data['username']} has left the room."}, room=data['room'])

if __name__ == '__main__':
    socketio.run(app, debug=True)
